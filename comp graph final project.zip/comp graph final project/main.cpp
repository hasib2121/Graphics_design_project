#include <iostream>
#include<GL/gl.h>
#include <windows.h>
#include <GL/glut.h>
#include <math.h>
#include<time.h>
#include <stdlib.h>
using namespace std;

bool day = true;
bool screenOne=true;
bool screenTwo=false;

const float PI = 3.14159265f;

void H_Line(float x1, float y1, float x2, float y2)
{
    glColor3ub(60,60,60);
    glBegin(GL_LINES);
        glVertex2f(x1, y1);
        glVertex2f(x2, y2);
    glEnd();
}

void H_Circle(float radius, float xc, float yc,float r,float g, float b)
{
    glColor3ub(r, g, b);
    glBegin(GL_POLYGON);
    for (int i = 0; i < 200; i++) {
        float pi = 3.1416;
        float A = (i * 2 * pi) / 200;
        float r = radius;
        float x = r * cos(A);
        float y = r * sin(A);
        glVertex2f(x + xc, y + yc);
    }
    glEnd();
}

void H_Sky()//SKY01
{

    if(day){
        glBegin(GL_POLYGON);
        glColor3ub(135,206,235);
        glVertex2f(-10,2);
        glVertex2f(-10,8);
        glVertex2f(10,8);
        glVertex2f(10,2);
        glEnd();
    }
    else{
        glBegin(GL_POLYGON);
        glColor3ub(0,0,0);
        glVertex2f(-10,2);
	    glVertex2f(-10,8);
	    glVertex2f(10,8);
	    glVertex2f(10,2);
	    glEnd();
	}
}

void H_Sun(float cx, float cy, float r, int num_segments)//SUN02
{

    if(day){
    glBegin(GL_TRIANGLE_FAN);
    glColor3ub(234,90,62);
    glVertex2f(cx, cy);

    for (int i = 0; i <= num_segments; ++i) {
        float theta = 2.0f * PI * float(i) / float(num_segments);
        float x = r * cosf(theta);
        float y = r * sinf(theta);
        glVertex2f(cx + x, cy + y);
    }
    glEnd();
    }

    else{
    glBegin(GL_TRIANGLE_FAN);
    glColor3ub(190,190,190);
    glVertex2f(cx, cy);

    for (int i = 0; i <= num_segments; ++i) {
        float theta = 2.0f * PI * float(i) / float(num_segments);
        float x = r * cosf(theta);
        float y = r * sinf(theta);
        glVertex2f(cx + x, cy + y);
    }
    glEnd();
    }
}

float movecloud1 = 0.0f;
float movecloud2 = 0.0f;
float movecloud3 = 0.0f;

void H_Cloud()//CLD03
{

    if(day){

        glPushMatrix();
        glTranslatef(movecloud1,0,0);
        H_Circle(0.5,-6,7,230,230,230);
        H_Circle(0.4,-5.2,7.2,230,230,230);
        H_Circle(0.4,-5.3,6.6,230,230,230);
        H_Circle(0.4,-4.6,6.8,230,230,230);
        glPopMatrix();

        //cloud 2
        glPushMatrix();
        glTranslatef(movecloud2,0,0);
        H_Circle(0.5,-1.5,7,230,230,230);
        H_Circle(0.4,-0.8,7.4,230,230,230);
        H_Circle(0.5,-0.8,6.6,230,230,230);
        H_Circle(0.5,-0.1,7.1,230,230,230);
        glPopMatrix();

        //cloud 3
        glPushMatrix();
        glTranslatef(movecloud3,0,0);
        H_Circle(0.6,7.8,7,230,230,230);
        H_Circle(0.5,8.8,7.4,230,230,230);
        H_Circle(0.5,8.6,6.7,230,230,230);
        H_Circle(0.4,9.4,6.8,230,230,230);
        glPopMatrix();
    }
    else{

        //cloud 1
        glPushMatrix();
        glTranslatef(movecloud1,0,0);
        H_Circle(0.5,-6,7,204,204,204);
        H_Circle(0.4,-5.2,7.2,204,204,204);
        H_Circle(0.4,-5.3,6.6,204,204,204);
        H_Circle(0.4,-4.6,6.8,204,204,204);
        glPopMatrix();

        //cloud 2
        glPushMatrix();
        glTranslatef(movecloud2,0,0);
        H_Circle(0.5,-1.5,7,204,204,204);
        H_Circle(0.4,-0.8,7.4,204,204,204);
        H_Circle(0.5,-0.8,6.6,204,204,204);
        H_Circle(0.5,-0.1,7.1,204,204,204);
        glPopMatrix();

        //cloud 3
        glPushMatrix();
        glTranslatef(movecloud3,0,0);
        H_Circle(0.6,7.8,7,204,204,204);
        H_Circle(0.5,8.8,7.4,204,204,204);
        H_Circle(0.5,8.6,6.7,204,204,204);
        H_Circle(0.4,9.4,6.8,204,204,204);
        glPopMatrix();
    }
}

void H_Updatecloud(int value)//UCLD02
{

    float speed = 0.02f;
    float resetThreshold = 17.0f;
    float resetX = -10.0f;

    movecloud1 += speed; if (movecloud1 > resetThreshold) movecloud1 = resetX;
    movecloud2 += speed; if (movecloud2 > resetThreshold) movecloud2 = resetX;
    movecloud3 += speed; if (movecloud3 > resetThreshold) movecloud3 = resetX;

    glutPostRedisplay();
    glutTimerFunc(20,H_Updatecloud,0);
}

void H_tree(float r, float g, float b, float x, float y, float z) //tree1
{

    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(x,y,z);

    glBegin(GL_POLYGON);
    glColor3ub(140,25,0);
    glVertex2f(-9,-0.2);
    glVertex2f(-9,0.2);
    glVertex2f(-8.9,0.2);
    glVertex2f(-8.9, -0.2);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(r,g,b);
    glVertex2f(-9.2, 0.2);
    glVertex2f(-8.95, 0.4);
    glVertex2f(-8.7, 0.2);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(r,g,b);
    glVertex2f(-9.2, 0.3);
    glVertex2f(-8.95, 0.5);
    glVertex2f(-8.7, 0.3);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(r,g,b);
    glVertex2f(-9.2, 0.4);
    glVertex2f(-8.95, 0.6);
    glVertex2f(-8.7, 0.4);
    glEnd();

    glPopMatrix();
}

void H_Tree()//tree_1-7
{

    if(day){
        H_tree(23,178,79,0,1.8,0);
        H_tree(23,178,79,3,1.8,0);
        H_tree(23,178,79,6,1.8,0);
        H_tree(23,178,79,10,1.8,0);
        H_tree(23,178,79,12.5,1.8,0);
        H_tree(23,178,79,15,1.8,0);
        H_tree(23,178,79,17.5,1.8,0);
    }
    else{
        H_tree(2,100,37,0,1.8,0);
        H_tree(2,100,37,3,1.8,0);
        H_tree(2,100,37,6,1.8,0);
        H_tree(2,100,37,10,1.8,0);
        H_tree(2,100,37,12.5,1.8,0);
        H_tree(2,100,37,15,1.8,0);
        H_tree(2,100,37,17.5,1.8,0);
    }
}

void H_Wall() //wall_1
{
    glBegin(GL_POLYGON);
    glColor3ub(188, 74, 60);
    glVertex2f(-10, 2);
    glVertex2f(-10, 2.7);
    glVertex2f(10, 2.7);
    glVertex2f(10, 2);
    glEnd();

    H_Tree();
}

void H_Land()//LND_07
{

    if(day){
        glBegin(GL_QUADS);
        glColor3ub(124,252,0);
        glVertex2f(-10,0);
        glVertex2f(-10,2);
        glVertex2f(10,2);
        glVertex2f(10,0);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(124,252,0);
        glVertex2f(-10, -4);
        glVertex2f(-10, -3);
        glVertex2f(10, -3);
        glVertex2f(10, -4);
        glEnd();
        H_Wall();

    }
    else{
        glBegin(GL_QUADS);
        glColor3ub(102,154,27);
        glVertex2f(-10,0);
        glVertex2f(-10,2);
        glVertex2f(10,2);
        glVertex2f(10,0);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(102,154,27);
        glVertex2f(-10, -4);
        glVertex2f(-10, -3);
        glVertex2f(10, -3);
        glVertex2f(10, -4);
        glEnd();
        H_Wall();

    }
}

float _angle1 = 0.0f; //trbn
void H_wind_turbine(float a, float b, float c, float x, float y, float z)//WINDT08
{

    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glScalef(a, b, c);
    glTranslatef(x,y,z);

    glBegin(GL_POLYGON);
    glColor3ub(55,55,57);
    glVertex2f(8.8, 0.55);
    glVertex2f(8.8, 0.6);
    glVertex2f(9.1, 0.6);
    glVertex2f(9.1, 0.55);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(200, 200, 200);
    glVertex2f(8.88, 0.6);
    glVertex2f(8.88, 2.18);
    glVertex2f(9.02, 2.18);
    glVertex2f(9.02, 0.6);
    glEnd();

    glPushMatrix();
    glTranslatef(8.945f, 2.175f, 0.0f);  // Move to center of blade
    glRotatef(_angle1, 0.0f, 0.0f, 1.0f); // Rotate around Z
    glTranslatef(-8.945f, -2.175f, 0.0f); // Move back

    glBegin(GL_POLYGON);
    glColor3ub(230, 230, 230);
    glVertex2f(8.38, 1.68);
    glVertex2f(8.32, 1.7);
    glVertex2f(8.712, 2.147);
    glVertex2f(8.945, 2.175);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(230, 230, 230);
    glVertex2f(8.945, 2.175);
    glVertex2f(8.817, 2.914);
    glVertex2f(8.857, 2.967);
    glVertex2f(9.045, 2.4);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(230, 230, 230);
    glVertex2f(8.945, 2.175);
    glVertex2f(9.65, 1.92);
    glVertex2f(9.68, 1.86);
    glVertex2f(9.084, 1.994);
    glEnd();

    H_Circle(0.105, 8.945, 2.175, 255, 255, 255);

    //red
    glBegin(GL_POLYGON);
    glColor3ub(185, 25, 25);
    glVertex2f(8.38, 1.68);
    glVertex2f(8.32, 1.7);
    glVertex2f(8.3920473519525, 1.7825779468883);
    glVertex2f(8.4630120614104, 1.752256661938);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(185, 25, 25);
    glVertex2f(8.8362040688834, 2.8040848505408);
    glVertex2f(8.817, 2.914);
    glVertex2f(8.857, 2.967);
    glVertex2f(8.8924561211847, 2.8598390970698);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(185, 25, 25);
    glVertex2f(9.5464102700322, 1.9570956561623);
    glVertex2f(9.65, 1.92);
    glVertex2f(9.68, 1.86);
    glVertex2f(9.5712720301, 1.8839728324333);
    glEnd();

    glPopMatrix();

    glPopMatrix();
}

void H_Wind_Turbine_update(int value)//UWINDT04
{

    _angle1 += 2.0f;
	glutPostRedisplay();

	glutTimerFunc(20, H_Wind_Turbine_update, 0);
}

void H_Wind_Turbine() //WNDT_08
{
    H_wind_turbine(1, 1.2, 1, -0.5, 0.5, 0);
    H_wind_turbine(1, 1.2, 1, -2.1, 0.5, 0);

    H_wind_turbine(1, 1.2, 1, 0.3, 0, 0);
    H_wind_turbine(1, 1.2, 1, -1.3, 0, 0);

    H_wind_turbine(1, 1.2, 1, -16.8, 0.5, 0);
    H_wind_turbine(1, 1.2, 1, -18.3, 0.5, 0);

    H_wind_turbine(1, 1.2, 1, -16, 0, 0);
    H_wind_turbine(1, 1.2, 1, -17.6, 0, 0);
}

void H_Road()//ROAD14
{

    glBegin(GL_QUADS); //road
    glColor3ub(71,72,76);
    glVertex2f(-10,-2.5);
    glVertex2f(-10,-0.5);
    glVertex2f(10,-0.5);
    glVertex2f(10,-2.5);
    glEnd();

    glBegin(GL_QUADS); //road side walk way 1
    glColor3ub(204,204,188);
    glVertex2f(-10,-3);
    glVertex2f(-10,-2.5);
    glVertex2f(10,-2.5);
    glVertex2f(10,-3);
    glEnd();

    glBegin(GL_QUADS); //road side walk way 2
    glColor3ub(204,204,188);
    glVertex2f(-10,-0.5);
    glVertex2f(-10,0);
    glVertex2f(10,0);
    glVertex2f(10,-0.5);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(235,232,226);
    glVertex2f(-9.8,-1.6);
    glVertex2f(-9.8,-1.4);
    glVertex2f(-8.2,-1.4);
    glVertex2f(-8.2,-1.6);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(235,232,226);
    glVertex2f(-7,-1.6);
    glVertex2f(-7,-1.4);
    glVertex2f(-5.4,-1.4);
    glVertex2f(-5.4,-1.6);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(235,232,226);
    glVertex2f(-4.2,-1.6);
    glVertex2f(-4.2,-1.4);
    glVertex2f(-2.8,-1.4);
    glVertex2f(-2.8,-1.6);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(235,232,226);
    glVertex2f(-0.4,-1.6);
    glVertex2f(-0.4,-1.4);
    glVertex2f(1.2,-1.4);
    glVertex2f(1.2,-1.6);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(235,232,226);
    glVertex2f(2.2,-1.6);
    glVertex2f(2.2,-1.4);
    glVertex2f(3.8,-1.4);
    glVertex2f(3.8,-1.6);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(235,232,226);
    glVertex2f(5,-1.6);
    glVertex2f(5,-1.4);
    glVertex2f(6.6,-1.4);
    glVertex2f(6.6,-1.6);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(235,232,226);
    glVertex2f(7.8,-1.6);
    glVertex2f(7.8,-1.4);
    glVertex2f(9.4,-1.4);
    glVertex2f(9.4,-1.6);
    glEnd();


}

void H_drawAirplane(float x, float y, float z){

    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(x,y,z);

    // Main Body
    if (day) glColor3ub(251, 251, 251);
    else glColor3ub(180, 180, 180);
    glBegin(GL_POLYGON);
        glVertex2f(1.66, 5.88); glVertex2f(4.57, 5.37); glVertex2f(4.97, 5.29);
        glVertex2f(5.13, 5.24); glVertex2f(5.19, 5.22); glVertex2f(5.2, 5.2);
        glVertex2f(5.06, 5.14); glVertex2f(4.74, 5.11); glVertex2f(4.34, 5.09);
        glVertex2f(3.79, 5.09); glVertex2f(3.30, 5.13); glVertex2f(3.02, 5.15);
        glVertex2f(2.46, 5.30); glVertex2f(2.16, 5.33); glVertex2f(1.87, 5.38);
        glVertex2f(1.65, 5.43); glVertex2f(1.51, 5.48); glVertex2f(1.39, 5.54);
        glVertex2f(1.32, 5.59); glVertex2f(1.28, 5.63); glVertex2f(1.27, 5.66);
        glVertex2f(1.26, 5.69); glVertex2f(1.27, 5.71); glVertex2f(1.29, 5.73);
        glVertex2f(1.30, 5.75); glVertex2f(1.36, 5.76); glVertex2f(1.40, 5.77);
        glVertex2f(1.41, 5.78); glVertex2f(1.47, 5.83); glVertex2f(1.50, 5.84);
        glVertex2f(1.55, 5.87); glVertex2f(1.60, 5.88); glVertex2f(1.66, 5.88);
    glEnd();

    // Vertical Tail Fin
    if (day) glColor3ub(237, 104, 233); else glColor3ub(100, 80, 150);
    glBegin(GL_POLYGON);
        glVertex2f(2.51, 5.38); glVertex2f(2.53, 5.38); glVertex2f(2.53, 5.35);
        glVertex2f(2.52, 5.33); glVertex2f(2.51, 5.31); glVertex2f(2.50, 5.28);
        glVertex2f(2.50, 5.22); glVertex2f(2.50, 5.17); glVertex2f(2.48, 5.18);
        glVertex2f(2.46, 5.20); glVertex2f(2.46, 5.30); glVertex2f(2.49, 5.36);
        glVertex2f(2.51, 5.38);
    glEnd();

    // Rear Fin (Inner Color Fill)
    glColor3ub(245, 245, 245);
    glBegin(GL_POLYGON);
        glVertex2f(2.97, 5.30); glVertex2f(3.02, 5.28); glVertex2f(3.02, 5.18);
        glVertex2f(3.00, 5.11); glVertex2f(2.58, 5.14); glVertex2f(2.50, 5.22);
        glVertex2f(2.51, 5.31); glVertex2f(2.54, 5.37); glVertex2f(2.60, 5.4);
        glVertex2f(2.90, 5.32); glVertex2f(2.97, 5.30);
    glEnd();

    // Left Wing
    if (day) glColor3ub(237, 104, 233); else glColor3ub(100, 80, 150);
    glBegin(GL_POLYGON);
        glVertex2f(2.6, 5.4); glVertex2f(3.75, 5.52); glVertex2f(3.90615, 5.65);
        glVertex2f(3.82426, 5.45); glVertex2f(3.02531, 5.28); glVertex2f(2.6, 5.4);
    glEnd();

    // Wing Shadow Detail
    glColor3ub(241, 241, 241);
    glBegin(GL_POLYGON);
        glVertex2f(3.28, 5.31); glVertex2f(3.50238, 5.26); glVertex2f(3.6898, 5.23);
        glVertex2f(3.92053, 5.20); glVertex2f(4.16875, 5.18); glVertex2f(4.37074, 5.18);
        glVertex2f(4.58759, 5.17); glVertex2f(4.89, 5.18); glVertex2f(5.02798, 5.17);
        glVertex2f(5.15, 5.24); glVertex2f(5.17924, 5.15); glVertex2f(5.06489, 5.14);
        glVertex2f(4.74918, 5.11); glVertex2f(4.34352, 5.09); glVertex2f(3.79875, 5.09);
        glVertex2f(3.30356, 5.13); glVertex2f(3.02269, 5.15); glVertex2f(3.02519, 5.18);
        glVertex2f(3.02791, 5.21); glVertex2f(3.02791, 5.25); glVertex2f(3.06082, 5.25);
        glVertex2f(3.28, 5.31);
    glEnd();

    // Right Wing
    if (day) glColor3ub(237, 104, 233); else glColor3ub(100, 80, 150);
    glBegin(GL_POLYGON);
        glVertex2f(4.621, 5.38); glVertex2f(4.678, 5.38); glVertex2f(4.742, 5.40);
        glVertex2f(5.1799, 5.85); glVertex2f(5.4413, 5.81); glVertex2f(5.165, 5.31);
        glVertex2f(5.13, 5.24); glVertex2f(4.9725, 5.29); glVertex2f(4.622, 5.38);
    glEnd();

    // Rear Tail Fin Right Side
    if (day) glColor3ub(237, 104, 233); else glColor3ub(100, 80, 150);
    glBegin(GL_POLYGON);
        glVertex2f(5.206, 5.37); glVertex2f(5.3847, 5.37); glVertex2f(5.0279, 5.17);
        glVertex2f(4.8272, 5.18); glVertex2f(4.7211, 5.20); glVertex2f(4.6917, 5.23);
        glVertex2f(5.206, 5.37);
    glEnd();

    // Window Series (Black)
    for (int i = 0; i < 42; i++) {
        if (i >= 16 && i <= 31) continue;  // Skip some to maintain spacing
        float dx = cos(-10 * M_PI / 180) * 0.06 * i;
        float dy = sin(-10 * M_PI / 180) * 0.06 * i;
        glColor3ub(0, 0, 0);
        glBegin(GL_POLYGON);
            glVertex2f(1.91106 + dx, 5.67 + dy);
            glVertex2f(1.91607 + dx, 5.71 + dy);
            glVertex2f(1.95433 + dx, 5.71 + dy);
            glVertex2f(1.94986 + dx, 5.67 + dy);
        glEnd();
    }

    // Headlight / Nose Detail

    glColor3ub(0, 0, 0);
    glBegin(GL_POLYGON);
        glVertex2f(1.4769, 5.83); glVertex2f(1.4953, 5.83); glVertex2f(1.5176, 5.83);
        glVertex2f(1.5417, 5.82); glVertex2f(1.5658, 5.81); glVertex2f(1.5899, 5.81);
        glVertex2f(1.6052, 5.79); glVertex2f(1.6056, 5.78); glVertex2f(1.5970, 5.76);
        glVertex2f(1.5873, 5.74); glVertex2f(1.5750, 5.74); glVertex2f(1.5552, 5.74);
        glVertex2f(1.5246, 5.74); glVertex2f(1.4891, 5.749); glVertex2f(1.4573, 5.75);
        glVertex2f(1.4307, 5.76); glVertex2f(1.4047, 5.77);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(100, 100, 100);
    glVertex2f(1.7, 5.16);
    glVertex2f(1.7258757592686, 5.4189830535357);
    glVertex2f(1.8, 5.4);
    glVertex2f(1.74, 5.14);
    glEnd();

    H_Circle(0.1, 1.71, 5.07, 0, 0, 0);

    glBegin(GL_POLYGON);
    glColor3ub(100, 100, 100);
    glVertex2f(4.14, 4.98);
    glVertex2f(4.1405349044489, 5.1058992979496);
    glVertex2f(4.24, 5.1);
    glVertex2f(4.2, 4.98);
    glEnd();

    H_Circle(0.1,4.17, 4.98,0 ,0, 0);
    glPopMatrix();

}

float H_Plane_Position_X = 0.0f;
float H_Plane_Position_Y = 0.0f;
void H_Plane(){
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(H_Plane_Position_X, H_Plane_Position_Y,0);

    H_drawAirplane(5, -6.5, 0);

    glPopMatrix();
}

bool H_movePlane = false;

void H_update_Plane(int value)
{
    if (!H_movePlane) {
        if (H_Plane_Position_X > -8.0f) {
            // Move left only
            H_Plane_Position_X -= 0.03f;
        } else if (H_Plane_Position_X > -20.0f) {
            // Fly diagonally (left and up)
            H_Plane_Position_X -= 0.03f;
            H_Plane_Position_Y += 0.02f;
        } else {
            // Reset position to start again
            H_Plane_Position_X = 10.0f;
            H_Plane_Position_Y = 0.0f;
        }
    }

    glutPostRedisplay();
    glutTimerFunc(20, H_update_Plane, 0);
}

float wave4X = -6.5f;
float wave5X = 0.0f;
float wave6X = 5.5f;
float wave7X = -8.5f;
float wave8X = -1.5f;
float wave9X = 7.0f;

void H_SeaWaves()

{
    glColor3ub(255, 255, 255);

    glPushMatrix();
    glTranslatef(wave4X, 0.0f, 0.0f);
    glBegin(GL_QUADS);
    glVertex2f(0.0f, -5.55f);
    glVertex2f(0.0f, -5.5f);
    glVertex2f(2.0f, -5.5f);
    glVertex2f(2.0f, -5.55f);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(wave5X, 0.0f, 0.0f);
    glBegin(GL_QUADS);
    glVertex2f(0.0f, -5.55f);
    glVertex2f(0.0f, -5.5f);
    glVertex2f(2.0f, -5.5f);
    glVertex2f(2.0f, -5.55f);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(wave6X, 0.0f, 0.0f);
    glBegin(GL_QUADS);
    glVertex2f(0.0f, -5.55f);
    glVertex2f(0.0f, -5.5f);
    glVertex2f(2.0f, -5.5f);
    glVertex2f(2.0f, -5.55f);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(wave7X, 0.0f, 0.0f);
    glBegin(GL_QUADS);
    glVertex2f(0.0f, -7.05f);
    glVertex2f(0.0f, -7.0f);
    glVertex2f(2.0f, -7.0f);
    glVertex2f(2.0f, -7.05f);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(wave8X, 0.0f, 0.0f);
    glBegin(GL_QUADS);
    glVertex2f(0.0f, -7.05f);
    glVertex2f(0.0f, -7.0f);
    glVertex2f(2.0f, -7.0f);
    glVertex2f(2.0f, -7.05f);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(wave9X, 0.0f, 0.0f);
    glBegin(GL_QUADS);
    glVertex2f(0.0f, -7.05f);
    glVertex2f(0.0f, -7.0f);
    glVertex2f(2.0f, -7.0f);
    glVertex2f(2.0f, -7.05f);
    glEnd();

    glPopMatrix();
}

void H_Wavemoving(int value)//UWAVE11
{
    float speed = 0.02f;
    float resetThreshold = 12.0f;
    float resetX = -12.0f;

    wave4X += speed; if (wave4X > resetThreshold) wave4X = resetX;
    wave5X += speed; if (wave5X > resetThreshold) wave5X = resetX;
    wave6X += speed; if (wave6X > resetThreshold) wave6X = resetX;
    wave7X += speed; if (wave7X > resetThreshold) wave7X = resetX;
    wave8X += speed; if (wave8X > resetThreshold) wave8X = resetX;
    wave9X += speed; if (wave9X > resetThreshold) wave9X = resetX;

    glutPostRedisplay();
    glutTimerFunc(16, H_Wavemoving, 0);
}

void H_Sea()//SEA23
{

    if(day){

    glBegin(GL_QUADS);
    glColor3ub(0,197,255);
    glVertex2f(-10,-8);
    glVertex2f(-10,-4);
    glVertex2f(10,-4);
    glVertex2f(10,-8);
    glEnd();
    }
    else{
    glBegin(GL_QUADS);
    glColor3ub(44,76,144);
    glVertex2f(-10,-8);
    glVertex2f(-10,-4);
    glVertex2f(10,-4);
    glVertex2f(10,-8);
    glEnd();
    }

    H_SeaWaves();

}


void H_Cruise_Ship_Window1(float x, float y, float z)
{
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(x,y,z);

    glBegin(GL_QUADS);
    glColor3ub(5, 174, 207);
    glVertex2f(-7, -4.2);
    glVertex2f(-7, -4.1);
    glVertex2f(-6.9, -4.1);
    glVertex2f(-6.9, -4.2);
    glEnd();

    H_Line(-7, -4.2, -6.9, -4.2);
    H_Line(-7, -4.2, -7, -4.1);
    H_Line(-7, -4.1, -6.9, -4.1);
    H_Line(-6.9, -4.2, -6.9, -4.1);

    glPopMatrix();
}

void H_Cruise_Ship_Window2(float x, float y, float z)
{
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(x,y,z);

    H_Circle(0.08,-7.48, -4.48, 0, 0, 0);
    H_Circle(0.06,-7.48, -4.48, 5, 174, 207);

    glPopMatrix();
}

float H_Cruise_ShipPosition = 0.0f;
void H_Cruise_Ship()//CRUISE24
{
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(H_Cruise_ShipPosition,0,0);

    if(day){

        glBegin(GL_QUADS);
        glColor3ub(53, 69, 84);
        glVertex2f(-7.4, -4.8);
        glVertex2f(-7.6, -4.6);
        glVertex2f(-4.6, -4.6);
        glVertex2f(-4.9, -4.8);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(81, 13, 98);
        glVertex2f(-5.3, -4.3);
        glVertex2f(-5.3, -4.15);
        glVertex2f(-4.65, -4.15);
        glVertex2f(-4.55, -4.3);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(240, 240, 240);
        glVertex2f(-7.6, -4.6);
        glVertex2f(-7.82, -4.4);
        glVertex2f(-7.82, -4.34);
        glVertex2f(-5.22, -4.34);
        glVertex2f(-5.2, -4.3);
        glVertex2f(-4.18, -4.3);
        glVertex2f(-4.6, -4.6);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(53, 69, 84);
        glVertex2f(-7.6, -4.34);
        glVertex2f(-7.5567567543833, -4.2600000022784);
        glVertex2f(-5.18, -4.26);
        glVertex2f(-5.22, -4.34);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(240, 240, 240);
        glVertex2f(-7.5567567543833, -4.2600000022784);
        glVertex2f(-7.2, -3.6);
        glVertex2f(-5.6, -3.6);
        glVertex2f(-5.18, -4.26);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(240, 240, 240);
        glVertex2f(-6.4, -3.6);
        glVertex2f(-6.2, -3.4);
        glVertex2f(-5.9, -3.4);
        glVertex2f(-5.7, -3.6);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(5, 174, 207);
        glVertex2f(-6.32, -3.58);
        glVertex2f(-6.28, -3.53);
        glVertex2f(-5.835, -3.53);
        glVertex2f(-5.78, -3.58);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(5, 174, 207);
        glVertex2f(-6.24, -3.49);
        glVertex2f(-6.19, -3.44);
        glVertex2f(-5.91, -3.44);
        glVertex2f(-5.865, -3.49);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(240, 240, 240);
        glVertex2f(-6.07, -3.6);
        glVertex2f(-6.07, -3.4);
        glVertex2f(-6.03, -3.4);
        glVertex2f(-6.03, -3.6);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(5, 174, 207);
        glVertex2f(-6.7, -4.2);
        glVertex2f(-6.7, -4.1);
        glVertex2f(-5.446, -4.1);
        glVertex2f(-5.382, -4.2);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(5, 174, 207);
        glVertex2f(-6.7, -4);
        glVertex2f(-6.7, -3.9);
        glVertex2f(-5.57273, -3.9);
        glVertex2f(-5.509, -4);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(5, 174, 207);
        glVertex2f(-6.7, -3.8);
        glVertex2f(-6.7, -3.7);
        glVertex2f(-5.7, -3.7);
        glVertex2f(-5.6364, -3.8);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(53, 69, 84);
        glVertex2f(-7.05, -3.6);
        glVertex2f(-7.05, -3.3);
        glVertex2f(-6.9, -3.3);
        glVertex2f(-6.9, -3.6);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(240, 240, 240);
        glVertex2f(-7.1, -3.3);
        glVertex2f(-7.1, -3.2);
        glVertex2f(-6.85, -3.2);
        glVertex2f(-6.85, -3.3);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(53, 69, 84);
        glVertex2f(-6.7, -3.6);
        glVertex2f(-6.7, -3.3);
        glVertex2f(-6.55, -3.3);
        glVertex2f(-6.55, -3.6);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(240, 240, 240);
        glVertex2f(-6.75, -3.3);
        glVertex2f(-6.75, -3.2);
        glVertex2f(-6.5, -3.2);
        glVertex2f(-6.5, -3.3);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(240, 240, 240);
        glVertex2f(-7.05, -3.45);
        glVertex2f(-7.05, -3.4);
        glVertex2f(-6.9, -3.4);
        glVertex2f(-6.9, -3.45);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(240, 240, 240);
        glVertex2f(-6.7, -3.45);
        glVertex2f(-6.7, -3.4);
        glVertex2f(-6.55, -3.4);
        glVertex2f(-6.55, -3.45);
        glEnd();

        H_Cruise_Ship_Window1(0, 0, 0);
        H_Cruise_Ship_Window1(-0.2, 0, 0);
        H_Cruise_Ship_Window1(-0.4, 0, 0);
        H_Cruise_Ship_Window1(0, 0.2, 0);
        H_Cruise_Ship_Window1(-0.2, 0.2, 0);
        H_Cruise_Ship_Window1(0.1, 0.4, 0);
        H_Cruise_Ship_Window1(-0.1, 0.4, 0);

        H_Cruise_Ship_Window2(0, 0, 0);
        H_Cruise_Ship_Window2(0.5, 0, 0);
        H_Cruise_Ship_Window2(1, 0, 0);
        H_Cruise_Ship_Window2(1.5, 0, 0);
        H_Cruise_Ship_Window2(2, 0, 0);
        H_Cruise_Ship_Window2(2.5, 0, 0);

        glBegin(GL_QUADS);
        glColor3ub(53, 69, 84);
        glVertex2f(-7.2216, -3.64);
        glVertex2f(-7.2, -3.6);
        glVertex2f(-5.6, -3.6);
        glVertex2f(-5.57455, -3.64);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(53, 69, 84);
        glVertex2f(-4.43, -4.3);
        glVertex2f(-4.43, -3.6);
        glVertex2f(-4.4, -3.6);
        glVertex2f(-4.4, -4.3);
        glEnd();

        glBegin(GL_TRIANGLES);
        glColor3ub(255, 0, 0);
        glVertex2f(-4.43, -3.9);
        glVertex2f(-4.75, -3.75);
        glVertex2f(-4.43, -3.6);
        glEnd();

    }
    else{

        glBegin(GL_QUADS);
        glColor3ub(53, 69, 84);
        glVertex2f(-7.4, -4.8);
        glVertex2f(-7.6, -4.6);
        glVertex2f(-4.6, -4.6);
        glVertex2f(-4.9, -4.8);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(81, 13, 98);
        glVertex2f(-5.3, -4.3);
        glVertex2f(-5.3, -4.15);
        glVertex2f(-4.65, -4.15);
        glVertex2f(-4.55, -4.3);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(210, 210, 210);
        glVertex2f(-7.6, -4.6);
        glVertex2f(-7.82, -4.4);
        glVertex2f(-7.82, -4.34);
        glVertex2f(-5.22, -4.34);
        glVertex2f(-5.2, -4.3);
        glVertex2f(-4.18, -4.3);
        glVertex2f(-4.6, -4.6);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(53, 69, 84);
        glVertex2f(-7.6, -4.34);
        glVertex2f(-7.5567567543833, -4.2600000022784);
        glVertex2f(-5.18, -4.26);
        glVertex2f(-5.22, -4.34);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(220, 220, 220);
        glVertex2f(-7.5567567543833, -4.2600000022784);
        glVertex2f(-7.2, -3.6);
        glVertex2f(-5.6, -3.6);
        glVertex2f(-5.18, -4.26);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(220, 220, 220);
        glVertex2f(-6.4, -3.6);
        glVertex2f(-6.2, -3.4);
        glVertex2f(-5.9, -3.4);
        glVertex2f(-5.7, -3.6);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(5, 174, 207);
        glVertex2f(-6.32, -3.58);
        glVertex2f(-6.28, -3.53);
        glVertex2f(-5.835, -3.53);
        glVertex2f(-5.78, -3.58);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(5, 174, 207);
        glVertex2f(-6.24, -3.49);
        glVertex2f(-6.19, -3.44);
        glVertex2f(-5.91, -3.44);
        glVertex2f(-5.865, -3.49);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(220, 220, 220);
        glVertex2f(-6.07, -3.6);
        glVertex2f(-6.07, -3.4);
        glVertex2f(-6.03, -3.4);
        glVertex2f(-6.03, -3.6);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(5, 174, 207);
        glVertex2f(-6.7, -4.2);
        glVertex2f(-6.7, -4.1);
        glVertex2f(-5.446, -4.1);
        glVertex2f(-5.382, -4.2);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(5, 174, 207);
        glVertex2f(-6.7, -4);
        glVertex2f(-6.7, -3.9);
        glVertex2f(-5.57273, -3.9);
        glVertex2f(-5.509, -4);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(5, 174, 207);
        glVertex2f(-6.7, -3.8);
        glVertex2f(-6.7, -3.7);
        glVertex2f(-5.7, -3.7);
        glVertex2f(-5.6364, -3.8);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(53, 69, 84);
        glVertex2f(-7.05, -3.6);
        glVertex2f(-7.05, -3.3);
        glVertex2f(-6.9, -3.3);
        glVertex2f(-6.9, -3.6);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(220, 220, 220);
        glVertex2f(-7.1, -3.3);
        glVertex2f(-7.1, -3.2);
        glVertex2f(-6.85, -3.2);
        glVertex2f(-6.85, -3.3);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(53, 69, 84);
        glVertex2f(-6.7, -3.6);
        glVertex2f(-6.7, -3.3);
        glVertex2f(-6.55, -3.3);
        glVertex2f(-6.55, -3.6);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(220, 220, 220);
        glVertex2f(-6.75, -3.3);
        glVertex2f(-6.75, -3.2);
        glVertex2f(-6.5, -3.2);
        glVertex2f(-6.5, -3.3);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(220, 220, 220);
        glVertex2f(-7.05, -3.45);
        glVertex2f(-7.05, -3.4);
        glVertex2f(-6.9, -3.4);
        glVertex2f(-6.9, -3.45);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(220, 220, 220);
        glVertex2f(-6.7, -3.45);
        glVertex2f(-6.7, -3.4);
        glVertex2f(-6.55, -3.4);
        glVertex2f(-6.55, -3.45);
        glEnd();

        H_Cruise_Ship_Window1(0, 0, 0);
        H_Cruise_Ship_Window1(-0.2, 0, 0);
        H_Cruise_Ship_Window1(-0.4, 0, 0);
        H_Cruise_Ship_Window1(0, 0.2, 0);
        H_Cruise_Ship_Window1(-0.2, 0.2, 0);
        H_Cruise_Ship_Window1(0.1, 0.4, 0);
        H_Cruise_Ship_Window1(-0.1, 0.4, 0);

        H_Cruise_Ship_Window2(0, 0, 0);
        H_Cruise_Ship_Window2(0.5, 0, 0);
        H_Cruise_Ship_Window2(1, 0, 0);
        H_Cruise_Ship_Window2(1.5, 0, 0);
        H_Cruise_Ship_Window2(2, 0, 0);
        H_Cruise_Ship_Window2(2.5, 0, 0);

        glBegin(GL_QUADS);
        glColor3ub(53, 69, 84);
        glVertex2f(-7.2216, -3.64);
        glVertex2f(-7.2, -3.6);
        glVertex2f(-5.6, -3.6);
        glVertex2f(-5.57455, -3.64);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(53, 69, 84);
        glVertex2f(-4.43, -4.3);
        glVertex2f(-4.43, -3.6);
        glVertex2f(-4.4, -3.6);
        glVertex2f(-4.4, -4.3);
        glEnd();

        glBegin(GL_TRIANGLES);
        glColor3ub(200, 0, 0);
        glVertex2f(-4.43, -3.9);
        glVertex2f(-4.75, -3.75);
        glVertex2f(-4.43, -3.6);
        glEnd();

    }
    glPopMatrix();
}

bool H_Cruise_Ship_Stop = false;

void H_updateCruise_Ship(int value)//UCRUISES12
{
    if (!H_Cruise_Ship_Stop) {
        H_Cruise_ShipPosition += 0.03f;
        if (H_Cruise_ShipPosition > 18.0f) {
            H_Cruise_ShipPosition = -10.0f;
        }
    }
    glutPostRedisplay();
    glutTimerFunc(20, H_updateCruise_Ship, 0);
}

void H_Cargo_ShipLine(float x1, float y1, float x2, float y2)
{
    glColor3ub(240, 240, 240);
    glBegin(GL_LINES);
        glVertex2f(x1, y1);
        glVertex2f(x2, y2);
    glEnd();
}

void H_Cargo_Ship_Window(float x, float y, float z)
{
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(x,y,z);

    glBegin(GL_QUADS);
    glColor3ub(5, 174, 207);
    glVertex2f(6.4, -6.8);
    glVertex2f(6.4, -6.7);
    glVertex2f(6.5, -6.7);
    glVertex2f(6.5, -6.8);
    glEnd();

    H_Line(6.4, -6.8, 6.4, -6.7);
    H_Line(6.4, -6.8, 6.5, -6.8);
    H_Line(6.4, -6.7, 6.5, -6.7);
    H_Line(6.5, -6.8, 6.5, -6.7);

    glPopMatrix();
}

void H_Cargo_Ship_BodyPart(float x, float y, float z)
{
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(x,y,z);

    glBegin(GL_POLYGON);
    glColor3ub(10, 55, 123);
    glVertex2f(4.4, -7.35);
    glVertex2f(4.4, -7.25);
    glVertex2f(4.45, -7.25);
    glVertex2f(4.45, -7.35);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3ub(1, 44, 87);
    glVertex2f(4.38, -7.25);
    glVertex2f(4.38, -7.22);
    glVertex2f(4.47, -7.22);
    glVertex2f(4.47, -7.25);
    glEnd();

    glPopMatrix();
}

void H_Container(float x, float y, float z, float r, float g, float b)
{
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(x,y,z);

    glBegin(GL_POLYGON);
    glColor3ub(r, g, b);
    glVertex2f(4.1, -6.95);
    glVertex2f(4.1, -6.75);
    glVertex2f(4.5, -6.75);
    glVertex2f(4.5, -6.95);
    glEnd();

    H_Line(4.1, -6.95, 4.1, -6.75);
    H_Line(4.1, -6.95, 4.5, -6.95);
    H_Line(4.1, -6.75, 4.5, -6.75);
    H_Line(4.5, -6.95, 4.5, -6.75);

    glPopMatrix();
}

float H_Cargo_ShipPosition = 0.0f;
void H_Cargo_Ship()//CARGO25
{
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(H_Cargo_ShipPosition,0,0);

    if(day){

        H_Container(0, 0.2, 0, 194, 194, 194);
        H_Container(0.4, 0.2, 0, 250, 228, 46);
        H_Container(0.8, 0.2, 0, 17, 85, 186);
        H_Container(1.2, 0.2, 0, 194, 194, 194);
        H_Container(1.6, 0.2, 0, 194, 3, 8);

        H_Container(0, 0, 0, 44, 185, 44);
        H_Container(0.4, 0, 0, 60, 60, 60);
        H_Container(0.8, 0, 0, 200, 0, 0);
        H_Container(1.2, 0, 0, 255, 228, 66);
        H_Container(1.6, 0, 0, 22, 85, 191);

        H_Container(0, -0.2, 0, 0, 73, 186);
        H_Container(0.4, -0.2, 0, 220, 220, 220);
        H_Container(0.8, -0.2, 0, 14, 155, 14);
        H_Container(1.2, -0.2, 0, 70, 70, 70);
        H_Container(1.6, -0.2, 0, 194, 194, 194);

        H_Container(0, -0.4, 0, 194, 194, 194);
        H_Container(0.4, -0.4, 0, 61, 61, 59);
        H_Container(0.8, -0.4, 0, 213, 19, 10);
        H_Container(1.2, -0.4, 0, 244, 225, 27);
        H_Container(1.6, -0.4, 0, 0, 162, 14);

        glBegin(GL_POLYGON);
        glColor3ub(200, 0, 0);
        glVertex2f(6.85, -7.6);
        glVertex2f(6.85, -7.4);
        glVertex2f(7.05, -7.4);
        glVertex2f(6.95, -7.6);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(10, 55, 123);
        glVertex2f(3.7, -7.6);
        glVertex2f(3.47275, -7.35);
        glVertex2f(7.11428, -7.35);
        glVertex2f(7.1, -7.4);
        glVertex2f(6.6, -7.6);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(10, 55, 123);
        glVertex2f(3.47275, -7.35);
        glVertex2f(3.2, -7.05);
        glVertex2f(3.95, -7.05);
        glVertex2f(4.2, -7.35);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(10, 55, 123);
        glVertex2f(6, -7.35);
        glVertex2f(6.2, -7.05);
        glVertex2f(7.2, -7.05);
        glVertex2f(7.11428, -7.35);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(240, 240, 240);
        glVertex2f(6.3, -7.05);
        glVertex2f(6.3, -6.4);
        glVertex2f(6.8, -6.4);
        glVertex2f(7.1, -6.7);
        glVertex2f(7.1, -7.05);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(10, 55, 123);
        glVertex2f(6.8, -6.4);
        glVertex2f(6.875, -6.3);
        glVertex2f(7.1, -6.3);
        glVertex2f(7.1, -6.7);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(200, 0, 0);
        glVertex2f(6.875, -6.3);
        glVertex2f(6.95, -6.2);
        glVertex2f(7.1, -6.2);
        glVertex2f(7.1, -6.3);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(240, 240, 240);
        glVertex2f(6.3, -6.4);
        glVertex2f(6.1, -6.2);
        glVertex2f(6.8, -6.2);
        glVertex2f(6.8, -6.4);
        glEnd();

        H_Line(6.3, -6.4, 6.8, -6.4);

        glBegin(GL_POLYGON);
        glColor3ub(5, 174, 207);
        glVertex2f(6.25, -6.35);
        glVertex2f(6.15, -6.25);
        glVertex2f(6.4, -6.25);
        glVertex2f(6.4, -6.35);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(5, 174, 207);
        glVertex2f(6.47, -6.35);
        glVertex2f(6.47, -6.25);
        glVertex2f(6.7, -6.25);
        glVertex2f(6.7, -6.35);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(240, 240, 240);
        glVertex2f(6.7, -7.05);
        glVertex2f(6.7, -6.86);
        glVertex2f(6.8, -6.86);
        glVertex2f(6.8, -7.05);
        glEnd();

        H_Line(6.7, -7.05, 6.7, -6.86);
        H_Line(6.7, -7.05, 6.8, -7.05);
        H_Line(6.7, -6.86, 6.8, -6.86);
        H_Line(6.8, -7.05, 6.8, -6.86);

        H_Circle(0.01, 6.78, -6.97, 0, 0, 0);

        H_Cargo_Ship_Window(0, 0, 0);
        H_Cargo_Ship_Window(0.2, 0, 0);
        H_Cargo_Ship_Window(0.4, 0, 0);
        H_Cargo_Ship_Window(0, 0.2, 0);
        H_Cargo_Ship_Window(0.2, 0.2, 0);

        H_Circle(0.1, 3.72, -7.22, 255, 255, 255);
        H_Circle(0.08, 3.72, -7.22, 69,118,247);

        H_Cargo_ShipLine(3.5, -7.05, 3.6, -6.8);
        H_Cargo_ShipLine(3.7, -7.05, 3.6, -6.8);
        H_Cargo_ShipLine(3.6, -7.05, 3.6, -6.72);
        H_Cargo_ShipLine(3.55, -6.8, 3.65, -6.8);
        H_Circle(0.04, 3.6, -6.7, 255, 255, 255);

        H_Cargo_Ship_BodyPart(0, 0, 0);
        H_Cargo_Ship_BodyPart(0.3, 0, 0);
        H_Cargo_Ship_BodyPart(0.6, 0, 0);
        H_Cargo_Ship_BodyPart(0.9, 0, 0);
        H_Cargo_Ship_BodyPart(1.2, 0, 0);
        H_Cargo_Ship_BodyPart(1.5, 0, 0);

    }
    else{

        H_Container(0, 0.2, 0, 194, 194, 194);
        H_Container(0.4, 0.2, 0, 250, 228, 46);
        H_Container(0.8, 0.2, 0, 17, 85, 186);
        H_Container(1.2, 0.2, 0, 194, 194, 194);
        H_Container(1.6, 0.2, 0, 194, 3, 8);

        H_Container(0, 0, 0, 44, 185, 44);
        H_Container(0.4, 0, 0, 60, 60, 60);
        H_Container(0.8, 0, 0, 200, 0, 0);
        H_Container(1.2, 0, 0, 255, 228, 66);
        H_Container(1.6, 0, 0, 22, 85, 191);

        H_Container(0, -0.2, 0, 0, 73, 186);
        H_Container(0.4, -0.2, 0, 220, 220, 220);
        H_Container(0.8, -0.2, 0, 14, 155, 14);
        H_Container(1.2, -0.2, 0, 70, 70, 70);
        H_Container(1.6, -0.2, 0, 194, 194, 194);

        H_Container(0, -0.4, 0, 194, 194, 194);
        H_Container(0.4, -0.4, 0, 61, 61, 59);
        H_Container(0.8, -0.4, 0, 213, 19, 10);
        H_Container(1.2, -0.4, 0, 244, 225, 27);
        H_Container(1.6, -0.4, 0, 0, 162, 14);

        glBegin(GL_POLYGON);
        glColor3ub(200, 0, 0);
        glVertex2f(6.85, -7.6);
        glVertex2f(6.85, -7.4);
        glVertex2f(7.05, -7.4);
        glVertex2f(6.95, -7.6);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(53, 69, 84);
        glVertex2f(3.7, -7.6);
        glVertex2f(3.47275, -7.35);
        glVertex2f(7.11428, -7.35);
        glVertex2f(7.1, -7.4);
        glVertex2f(6.6, -7.6);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(53, 69, 84);
        glVertex2f(3.47275, -7.35);
        glVertex2f(3.2, -7.05);
        glVertex2f(3.95, -7.05);
        glVertex2f(4.2, -7.35);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(53, 69, 84);
        glVertex2f(6, -7.35);
        glVertex2f(6.2, -7.05);
        glVertex2f(7.2, -7.05);
        glVertex2f(7.11428, -7.35);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(220, 220, 220);
        glVertex2f(6.3, -7.05);
        glVertex2f(6.3, -6.4);
        glVertex2f(6.8, -6.4);
        glVertex2f(7.1, -6.7);
        glVertex2f(7.1, -7.05);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(10, 55, 123);
        glVertex2f(6.8, -6.4);
        glVertex2f(6.875, -6.3);
        glVertex2f(7.1, -6.3);
        glVertex2f(7.1, -6.7);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(200, 0, 0);
        glVertex2f(6.875, -6.3);
        glVertex2f(6.95, -6.2);
        glVertex2f(7.1, -6.2);
        glVertex2f(7.1, -6.3);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(220, 220, 220);
        glVertex2f(6.3, -6.4);
        glVertex2f(6.1, -6.2);
        glVertex2f(6.8, -6.2);
        glVertex2f(6.8, -6.4);
        glEnd();

        H_Line(6.3, -6.4, 6.8, -6.4);

        glBegin(GL_POLYGON);
        glColor3ub(5, 174, 207);
        glVertex2f(6.25, -6.35);
        glVertex2f(6.15, -6.25);
        glVertex2f(6.4, -6.25);
        glVertex2f(6.4, -6.35);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(5, 174, 207);
        glVertex2f(6.47, -6.35);
        glVertex2f(6.47, -6.25);
        glVertex2f(6.7, -6.25);
        glVertex2f(6.7, -6.35);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(220, 220, 220);
        glVertex2f(6.7, -7.05);
        glVertex2f(6.7, -6.86);
        glVertex2f(6.8, -6.86);
        glVertex2f(6.8, -7.05);
        glEnd();

        H_Line(6.7, -7.05, 6.7, -6.86);
        H_Line(6.7, -7.05, 6.8, -7.05);
        H_Line(6.7, -6.86, 6.8, -6.86);
        H_Line(6.8, -7.05, 6.8, -6.86);

        H_Circle(0.01, 6.78, -6.97, 0, 0, 0);

        H_Cargo_Ship_Window(0, 0, 0);
        H_Cargo_Ship_Window(0.2, 0, 0);
        H_Cargo_Ship_Window(0.4, 0, 0);
        H_Cargo_Ship_Window(0, 0.2, 0);
        H_Cargo_Ship_Window(0.2, 0.2, 0);

        H_Circle(0.1, 3.72, -7.22, 255, 255, 255);
        H_Circle(0.08, 3.72, -7.22, 69,118,247);

        H_Cargo_ShipLine(3.5, -7.05, 3.6, -6.8);
        H_Cargo_ShipLine(3.7, -7.05, 3.6, -6.8);
        H_Cargo_ShipLine(3.6, -7.05, 3.6, -6.72);
        H_Cargo_ShipLine(3.55, -6.8, 3.65, -6.8);
        H_Circle(0.04, 3.6, -6.7, 255, 255, 255);

        H_Cargo_Ship_BodyPart(0, 0, 0);
        H_Cargo_Ship_BodyPart(0.3, 0, 0);
        H_Cargo_Ship_BodyPart(0.6, 0, 0);
        H_Cargo_Ship_BodyPart(0.9, 0, 0);
        H_Cargo_Ship_BodyPart(1.2, 0, 0);
        H_Cargo_Ship_BodyPart(1.5, 0, 0);

    }
    glPopMatrix();
}

bool H_Cargo_Ship_Stop = false;
void H_updateCargo_Ship(int value)//UCARGOS14
{
    if (!H_Cargo_Ship_Stop) {
        H_Cargo_ShipPosition -= 0.03f;
        if (H_Cargo_ShipPosition < -17.5f) {
            H_Cargo_ShipPosition = 10.0f;
        }
    }
    glutPostRedisplay();
    glutTimerFunc(20, H_updateCargo_Ship, 0);
}

 void Screen1(){

     H_Sky();
     H_Sun(-8.2,6.8,0.8,100);
     H_Cloud();
     H_Land();
     H_Wind_Turbine();
     H_Road();
     H_Plane();
     H_Sea();
     H_Cruise_Ship();
     H_Cargo_Ship();

}

void Screen2(){}

void display(){

    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT);
	glLineWidth(1);

    glMatrixMode(GL_MODELVIEW);
    if(screenOne){
        Screen1();
    }
    else if(screenTwo){
        Screen2();
    }
    glFlush();
    glutSwapBuffers();
}

void handleMouse(int button, int state, int x, int y)//Handle mouse press
{
	if (button == GLUT_LEFT_BUTTON)
	{
        day=true;
    }
    if (button == GLUT_RIGHT_BUTTON)
	{
	    day=false;
    }
    glutPostRedisplay();
}

void handleKeypress(unsigned char key, int x, int y)//Handle key press
{
    if(screenOne){
        switch (key) {

            case 'H':
            case 'h':
                H_Cruise_Ship_Stop =! H_Cruise_Ship_Stop; //Cruise Ship
                break;

            case 'A':
            case 'a':
                H_Cargo_Ship_Stop =! H_Cargo_Ship_Stop; //Cargo Ship
                break;

            case 'S':
            case 's':
                H_movePlane =! H_movePlane;
                break;


            case'1':
                screenOne=true;
                screenTwo=false;
                break;

            case'2':
                screenOne=false;
                screenTwo=true;
                break;
        }
    }
    else if(screenTwo){
        switch (key) {

            case'1':
                screenOne=true;
                screenTwo=false;
                break;

            case'2':
                screenOne=false;
                screenTwo=true;
                break;

        }
    }
    glutPostRedisplay();
}

int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
	glutCreateWindow("Plane Take off");
	gluOrtho2D(-10, 10, -8 ,8);
	glutInitWindowSize(320, 320);
	glutDisplayFunc(display);

	glutTimerFunc(0, H_Updatecloud, 0);
	glutTimerFunc(0, H_Wind_Turbine_update , 0);
	glutTimerFunc(0, H_update_Plane, 0);
	glutTimerFunc(0, H_Wavemoving, 0);
    glutTimerFunc(0, H_updateCruise_Ship, 0);
	glutTimerFunc(0, H_updateCargo_Ship, 0);

    glutKeyboardFunc(handleKeypress);
    glutMouseFunc(handleMouse);

	glutMainLoop();
	return 0;
}
